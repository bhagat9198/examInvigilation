var firebaseConfig = {
  apiKey: "AIzaSyD9hy0FW0wGGZ1b3XCUUPznr0byFCMBUNk",
  authDomain: "easyexamination-78608.firebaseapp.com",
  databaseURL: "https://easyexamination-78608.firebaseio.com",
  projectId: "easyexamination-78608",
  storageBucket: "easyexamination-78608.appspot.com",
  messagingSenderId: "797759442054",
  appId: "1:797759442054:web:410cd712c6a4c67c811507",
  measurementId: "G-6SMD9SD4QD"
};
// Initialize Firebase
firebase.initializeApp(firebaseConfig);
firebase.analytics();
